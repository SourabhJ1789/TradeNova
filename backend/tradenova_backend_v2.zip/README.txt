TradeNova Backend v2 - Zerodha & CoinDCX Integration

Instructions:
1. Place the 'clients' folder inside your 'backend' directory.
2. Update 'backend/api.py' to import:
   from clients.kite_client import KiteClient
   from clients.coindcx_client import CoinDCXClient
   Add startup/shutdown events as previously instructed.
3. Add environment variables in Render:
   - KITE_API_KEY, KITE_ACCESS_TOKEN, KITE_WATCHLIST, KITE_POLL_INTERVAL
   - COINDCX_WS, COINDCX_SYMBOLS
4. Ensure 'kiteconnect' and 'aiohttp' are in backend/requirements.txt.
5. Commit and push to GitHub, Render will auto-deploy.
